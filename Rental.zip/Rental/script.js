// Sample property data with multiple images
const properties = [
    {
        id: 1,
        title: "Modern Downtown Apartment",
        location: "Bandra West, Mumbai",
        price: 45000,
        type: "apartment",
        bedrooms: 2,
        bathrooms: 2,
        area: 1200,
        description: "Beautiful modern apartment in the heart of Bandra with stunning city views. Features include hardwood floors, modular kitchen, and floor-to-ceiling windows.",
        images: [
            "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1571468/pexels-photo-1571468.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1571453/pexels-photo-1571453.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1571467/pexels-photo-1571467.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        amenities: ["Air Conditioning", "Gym", "Swimming Pool", "Parking", "Balcony", "Pet Friendly"],
        agent: "Aakhil Mohammad",
        phone: "+91 98765 43210",
        email: "aakhil@rentease.com"
    },
    {
        id: 2,
        title: "Cozy Suburban House",
        location: "Koramangala, Bangalore",
        price: 32000,
        type: "house",
        bedrooms: 3,
        bathrooms: 2,
        area: 1800,
        description: "Charming 3-bedroom house in a quiet residential area. Perfect for families with a large garden, modern kitchen, and spacious living areas.",
        images: [
            "https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1396132/pexels-photo-1396132.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1396118/pexels-photo-1396118.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        amenities: ["Garden", "Car Parking", "Power Backup", "Water Supply", "Security"],
        agent: "Umesh Anjan",
        phone: "+91 87654 32109",
        email: "umesh@rentease.com"
    },
    {
        id: 3,
        title: "Luxury Penthouse Suite",
        location: "Golf Course Road, Gurgaon",
        price: 50000,
        type: "condo",
        bedrooms: 3,
        bathrooms: 3,
        area: 2200,
        description: "Stunning penthouse with panoramic city views, marble flooring, and premium finishes throughout. Includes private terrace and concierge service.",
        images: [
            "https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1643384/pexels-photo-1643384.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/2029667/pexels-photo-2029667.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/2029670/pexels-photo-2029670.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/2029674/pexels-photo-2029674.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/2029677/pexels-photo-2029677.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        amenities: ["Concierge Service", "Valet Parking", "Rooftop Pool", "Spa", "Club House", "Private Lift"],
        agent: "Swarjan Vattapali",
        phone: "+91 76543 21098",
        email: "Swarjan@rentease.com"
    },
    {
        id: 4,
        title: "Minimalist Studio Apartment",
        location: "Hauz Khas, New Delhi",
        price: 22000,
        type: "studio",
        bedrooms: 1,
        bathrooms: 1,
        area: 600,
        description: "Sleek studio apartment in trendy Hauz Khas village. High ceilings, modern amenities, and close to metro station. Perfect for young professionals.",
        images: [
            "https://images.pexels.com/photos/1457842/pexels-photo-1457842.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1457847/pexels-photo-1457847.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1457849/pexels-photo-1457849.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        amenities: ["High Speed Internet", "Furnished", "Metro Connectivity", "Cafes Nearby"],
        agent: "Prasad Korupolu",
        phone: "+91 65432 10987",
        email: "prasad@rentease.com"
    },
    {
        id: 5,
        title: "Family-Friendly Villa",
        location: "Whitefield, Bangalore",
        price: 38000,
        type: "house",
        bedrooms: 4,
        bathrooms: 3,
        area: 2400,
        description: "Spacious 4-bedroom villa in a gated community. Features include a large kitchen, servant room, and private garden with children's play area.",
        images: [
            "https://images.pexels.com/photos/1396132/pexels-photo-1396132.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1396118/pexels-photo-1396118.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1396119/pexels-photo-1396119.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1396125/pexels-photo-1396125.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        amenities: ["Gated Community", "Children's Play Area", "24/7 Security", "Power Backup", "Water Harvesting"],
        agent: "Aakhil Mohammad",
        phone: "+91 54321 09876",
        email: "aakhil@rentease.com"
    },
    {
        id: 6,
        title: "Seaside Apartment",
        location: "Marine Drive, Mumbai",
        price: 42000,
        type: "apartment",
        bedrooms: 2,
        bathrooms: 2,
        area: 1400,
        description: "Beautiful seaside apartment with direct sea view. Modern amenities, spacious balcony overlooking the Arabian Sea, and premium location.",
        images: [
            "https://images.pexels.com/photos/2029670/pexels-photo-2029670.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/2029667/pexels-photo-2029667.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/2029674/pexels-photo-2029674.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        amenities: ["Sea View", "Premium Location", "Swimming Pool", "Gym", "Concierge", "Balcony"],
        agent: "Umesh Anajan",
        phone: "+91 43210 98765",
        email: "Umesh@rentease.com"
    },
    {
        id: 7,
        title: "Budget-Friendly 1BHK",
        location: "Malviya Nagar, New Delhi",
        price: 18000,
        type: "apartment",
        bedrooms: 1,
        bathrooms: 1,
        area: 500,
        description: "Affordable 1BHK apartment in well-connected locality. Semi-furnished with basic amenities and close to metro station.",
        images: [
            "https://images.pexels.com/photos/1457842/pexels-photo-1457842.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1571468/pexels-photo-1571468.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        amenities: ["Semi-Furnished", "Metro Nearby", "Market Access", "Power Backup"],
        agent: "Prasad",
        phone: "+91 32109 87654",
        email: "prasad@rentease.com"
    },
    {
        id: 8,
        title: "Premium 2BHK Flat",
        location: "Powai, Mumbai",
        price: 35000,
        type: "apartment",
        bedrooms: 2,
        bathrooms: 2,
        area: 1100,
        description: "Well-maintained 2BHK flat in premium society with lake view. Modern amenities and excellent connectivity to IT hubs.",
        images: [
            "https://images.pexels.com/photos/1571453/pexels-photo-1571453.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1571467/pexels-photo-1571467.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/2029667/pexels-photo-2029667.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        amenities: ["Lake View", "Club House", "Swimming Pool", "Gym", "Children's Park"],
        agent: "Aakhil Mohammad",
        phone: "+91 21098 76543",
        email: "aakhil@rentease.com"
    },
    {
        id: 9,
        title: "Compact Studio",
        location: "Indiranagar, Bangalore",
        price: 15000,
        type: "studio",
        bedrooms: 1,
        bathrooms: 1,
        area: 400,
        description: "Compact and efficient studio apartment perfect for students and young professionals. Fully furnished with modern amenities.",
        images: [
            "https://images.pexels.com/photos/1457847/pexels-photo-1457847.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1457849/pexels-photo-1457849.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1457842/pexels-photo-1457842.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        amenities: ["Fully Furnished", "Wi-Fi", "Laundry Service", "24/7 Security"],
        agent: "Umesh Anjan",
        phone: "+91 10987 65432",
        email: "Umesh@rentease.com"
    },
    {
        id: 10,
        title: "Spacious 3BHK House",
        location: "Sector 62, Noida",
        price: 28000,
        type: "house",
        bedrooms: 3,
        bathrooms: 2,
        area: 1600,
        description: "Independent 3BHK house with parking space and small garden. Well-ventilated rooms and peaceful neighborhood.",
        images: [
            "https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1396132/pexels-photo-1396132.jpeg?auto=compress&cs=tinysrgb&w=800",
            "https://images.pexels.com/photos/1396119/pexels-photo-1396119.jpeg?auto=compress&cs=tinysrgb&w=800"
        ],
        amenities: ["Independent House", "Parking", "Garden", "Peaceful Area", "Good Connectivity"],
        agent: "Swarjan Vattapalli",
        phone: "+91 09876 54321",
        email: "swarjan@rentease.com"
    }
];

// Global variables
let filteredProperties = [...properties];
let currentImageIndex = 0;
let currentPropertyImages = [];

// DOM elements
const propertyGrid = document.getElementById('propertyGrid');
const loadingSpinner = document.getElementById('loadingSpinner');
const noResults = document.getElementById('noResults');
const modal = document.getElementById('propertyModal');
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const typeFilter = document.getElementById('typeFilter');
const priceFilter = document.getElementById('priceFilter');
const bedroomFilter = document.getElementById('bedroomFilter');
const clearFiltersBtn = document.getElementById('clearFilters');
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    showLoadingSpinner();
    setTimeout(() => {
        hideLoadingSpinner();
        displayProperties(properties);
    }, 1000);
    
    setupEventListeners();
});

// Event listeners
function setupEventListeners() {
    // Search functionality
    searchBtn.addEventListener('click', handleSearch);
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            handleSearch();
        }
    });
    
    // Filter functionality
    typeFilter.addEventListener('change', applyFilters);
    priceFilter.addEventListener('change', applyFilters);
    bedroomFilter.addEventListener('change', applyFilters);
    clearFiltersBtn.addEventListener('click', clearFilters);
    
    // Modal functionality
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModal();
        }
    });
    
    document.querySelector('.close').addEventListener('click', closeModal);
    document.getElementById('prevBtn').addEventListener('click', previousImage);
    document.getElementById('nextBtn').addEventListener('click', nextImage);
    
    // Mobile navigation
    hamburger.addEventListener('click', function() {
        navMenu.classList.toggle('active');
    });
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
            // Close mobile menu if open
            navMenu.classList.remove('active');
        });
    });
}

// Display properties
function displayProperties(propertiesToShow) {
    propertyGrid.innerHTML = '';
    
    if (propertiesToShow.length === 0) {
        showNoResults();
        return;
    }
    
    hideNoResults();
    
    propertiesToShow.forEach(property => {
        const propertyCard = createPropertyCard(property);
        propertyGrid.appendChild(propertyCard);
    });
}

// Create property card
function createPropertyCard(property) {
    const card = document.createElement('div');
    card.className = 'property-card';
    card.addEventListener('click', () => openModal(property));
    
    card.innerHTML = `
        <div class="property-image">
            <img src="${property.images[0]}" alt="${property.title}" loading="lazy">
            <div class="image-count">
                <i class="fas fa-camera"></i> ${property.images.length}
            </div>
            <div class="price-tag">₹${property.price.toLocaleString()}/mo</div>
        </div>
        <div class="property-info">
            <h3>${property.title}</h3>
            <div class="property-location">
                <i class="fas fa-map-marker-alt"></i>
                ${property.location}
            </div>
            <div class="property-features">
                <div class="feature">
                    <i class="fas fa-bed"></i>
                    ${property.bedrooms}
                </div>
                <div class="feature">
                    <i class="fas fa-bath"></i>
                    ${property.bathrooms}
                </div>
                <div class="feature">
                    <i class="fas fa-ruler-combined"></i>
                    ${property.area} sq ft
                </div>
            </div>
            <div class="property-type">${property.type}</div>
        </div>
    `;
    
    return card;
}

// Modal functionality
function openModal(property) {
    currentPropertyImages = property.images;
    currentImageIndex = 0;
    
    // Populate modal content
    document.getElementById('modalTitle').textContent = property.title;
    document.getElementById('modalLocation').querySelector('span').textContent = property.location;
    document.getElementById('modalPrice').textContent = `₹${property.price.toLocaleString()}/mo`;
    document.getElementById('modalBedrooms').textContent = property.bedrooms;
    document.getElementById('modalBathrooms').textContent = property.bathrooms;
    document.getElementById('modalArea').textContent = property.area.toLocaleString();
    document.getElementById('modalType').textContent = property.type.charAt(0).toUpperCase() + property.type.slice(1);
    document.getElementById('modalDescription').textContent = property.description;
    document.getElementById('modalAgent').textContent = property.agent;
    document.getElementById('modalPhone').textContent = property.phone;
    document.getElementById('modalEmail').textContent = property.email;
    
    // Populate amenities
    const amenitiesContainer = document.getElementById('modalAmenities');
    amenitiesContainer.innerHTML = '';
    property.amenities.forEach(amenity => {
        const amenityTag = document.createElement('span');
        amenityTag.className = 'amenity-tag';
        amenityTag.textContent = amenity;
        amenitiesContainer.appendChild(amenityTag);
    });
    
    // Setup image gallery
    setupImageGallery();
    
    // Show modal
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

function setupImageGallery() {
    const mainImage = document.getElementById('mainImage');
    const thumbnailsContainer = document.getElementById('thumbnails');
    
    // Set main image
    mainImage.src = currentPropertyImages[currentImageIndex];
    
    // Create thumbnails
    thumbnailsContainer.innerHTML = '';
    currentPropertyImages.forEach((image, index) => {
        const thumbnail = document.createElement('img');
        thumbnail.src = image;
        thumbnail.className = `thumbnail ${index === currentImageIndex ? 'active' : ''}`;
        thumbnail.addEventListener('click', () => {
            currentImageIndex = index;
            updateMainImage();
            updateThumbnails();
        });
        thumbnailsContainer.appendChild(thumbnail);
    });
}

function updateMainImage() {
    document.getElementById('mainImage').src = currentPropertyImages[currentImageIndex];
}

function updateThumbnails() {
    const thumbnails = document.querySelectorAll('.thumbnail');
    thumbnails.forEach((thumb, index) => {
        thumb.classList.toggle('active', index === currentImageIndex);
    });
}

function previousImage() {
    currentImageIndex = (currentImageIndex - 1 + currentPropertyImages.length) % currentPropertyImages.length;
    updateMainImage();
    updateThumbnails();
}

function nextImage() {
    currentImageIndex = (currentImageIndex + 1) % currentPropertyImages.length;
    updateMainImage();
    updateThumbnails();
}

// Search functionality
function handleSearch() {
    const searchTerm = searchInput.value.toLowerCase().trim();
    
    if (searchTerm === '') {
        filteredProperties = [...properties];
    } else {
        filteredProperties = properties.filter(property => 
            property.title.toLowerCase().includes(searchTerm) ||
            property.location.toLowerCase().includes(searchTerm) ||
            property.type.toLowerCase().includes(searchTerm)
        );
    }
    
    applyFilters();
}

// Filter functionality
function applyFilters() {
    let filtered = [...filteredProperties];
    
    // Apply type filter
    const selectedType = typeFilter.value;
    if (selectedType) {
        filtered = filtered.filter(property => property.type === selectedType);
    }
    
    // Apply price filter
    const selectedPrice = priceFilter.value;
    if (selectedPrice) {
        filtered = filtered.filter(property => {
            if (selectedPrice === '0-20000') return property.price <= 20000;
            if (selectedPrice === '20000-30000') return property.price > 20000 && property.price <= 30000;
            if (selectedPrice === '30000-40000') return property.price > 30000 && property.price <= 40000;
            if (selectedPrice === '40000+') return property.price > 40000;
            return true;
        });
    }
    
    // Apply bedroom filter
    const selectedBedrooms = bedroomFilter.value;
    if (selectedBedrooms) {
        filtered = filtered.filter(property => {
            if (selectedBedrooms === '4+') return property.bedrooms >= 4;
            return property.bedrooms.toString() === selectedBedrooms;
        });
    }
    
    showLoadingSpinner();
    setTimeout(() => {
        hideLoadingSpinner();
        displayProperties(filtered);
    }, 500);
}

function clearFilters() {
    searchInput.value = '';
    typeFilter.value = '';
    priceFilter.value = '';
    bedroomFilter.value = '';
    
    filteredProperties = [...properties];
    displayProperties(properties);
}

// Loading and no results
function showLoadingSpinner() {
    loadingSpinner.style.display = 'block';
    propertyGrid.style.display = 'none';
    noResults.style.display = 'none';
}

function hideLoadingSpinner() {
    loadingSpinner.style.display = 'none';
    propertyGrid.style.display = 'grid';
}

function showNoResults() {
    noResults.style.display = 'block';
    propertyGrid.style.display = 'none';
}

function hideNoResults() {
    noResults.style.display = 'none';
    propertyGrid.style.display = 'grid';
}

// Contact and favorite functionality
document.addEventListener('DOMContentLoaded', function() {
    // Contact button functionality
    document.getElementById('contactBtn').addEventListener('click', function() {
        const agent = document.getElementById('modalAgent').textContent;
        const phone = document.getElementById('modalPhone').textContent;
        const email = document.getElementById('modalEmail').textContent;
        
        const message = `Hello ${agent}, I'm interested in the property "${document.getElementById('modalTitle').textContent}". Please contact me to schedule a viewing.`;
        
        // Create mailto link
        const mailtoLink = `mailto:${email}?subject=Property Inquiry&body=${encodeURIComponent(message)}`;
        window.open(mailtoLink);
    });
    
    // Favorite button functionality
    document.getElementById('favoriteBtn').addEventListener('click', function() {
        const btn = this;
        const icon = btn.querySelector('i');
        
        if (icon.classList.contains('fas')) {
            icon.classList.remove('fas');
            icon.classList.add('far');
            btn.innerHTML = '<i class="far fa-heart"></i> Add to Favorites';
        } else {
            icon.classList.remove('far');
            icon.classList.add('fas');
            btn.innerHTML = '<i class="fas fa-heart"></i> Added to Favorites';
        }
    });
});

// Keyboard navigation for modal
document.addEventListener('keydown', function(e) {
    if (modal.style.display === 'block') {
        if (e.key === 'Escape') {
            closeModal();
        } else if (e.key === 'ArrowLeft') {
            previousImage();
        } else if (e.key === 'ArrowRight') {
            nextImage();
        }
    }
});